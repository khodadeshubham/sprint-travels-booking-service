package com.sprint.booking_service.dto;

import java.util.List;

import lombok.Data;

@Data
public class BookingRequestDto {

	private int numberOfPassenger;
	
	private Long busId;
	
	private List<PassengerDto> passengers;
	
}
