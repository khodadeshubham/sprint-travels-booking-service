package com.sprint.booking_service.dto;

import lombok.Data;

@Data
public class PassengerDto {

	private String firstName;
	private String lastName;
}
