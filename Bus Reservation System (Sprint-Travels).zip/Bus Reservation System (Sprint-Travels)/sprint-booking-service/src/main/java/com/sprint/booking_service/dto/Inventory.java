package com.sprint.booking_service.dto;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
public class Inventory {

	private Long busId;
	
	private String start;
	private String destination;
	private int seatsAvailable;
	private LocalDateTime lastUpdate; 
	private Double pricePerSeat;
}
