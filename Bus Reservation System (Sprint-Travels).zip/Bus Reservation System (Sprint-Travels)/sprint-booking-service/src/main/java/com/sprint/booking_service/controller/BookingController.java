package com.sprint.booking_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.sprint.booking_service.dto.BookingRequestDto;
import com.sprint.booking_service.dto.Inventory;
import com.sprint.booking_service.dto.Payment;
import com.sprint.booking_service.dto.PaymentRequest;
import com.sprint.booking_service.dto.UpdateSeatRequest;
import com.sprint.booking_service.model.Booking;
import com.sprint.booking_service.service.BookingService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/booking")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	@Qualifier("plain-inventory-client")
	WebClient inventoryClient;

	@Autowired
	@Qualifier("plain-payment-client")
	WebClient paymentClient;

	@PostMapping("/addNewBooking")
	public ResponseEntity<?> addBooking(@RequestBody BookingRequestDto request, @RequestHeader("Authorization") String token) {

		Inventory inventory = inventoryClient.get().uri("/getBusDetails/" + request.getBusId())
				.header("Authorization", token).retrieve().bodyToMono(Inventory.class).block();

		log.info("Bus details fetched");
		if (inventory.getSeatsAvailable() > request.getNumberOfPassenger()) {
			Booking newBooking = bookingService.addBooking(request);
			
			UpdateSeatRequest bookSeat = new UpdateSeatRequest();
			bookSeat.setBusId(request.getBusId());
			bookSeat.setSeats(request.getNumberOfPassenger());
			String updateSeatResponse = inventoryClient.post().uri("/updateSeats")
					.body(BodyInserters.fromValue(bookSeat)).header("Authorization", token).retrieve()
					.bodyToMono(String.class).block();
			
			if(updateSeatResponse.equals("updated")) {
				log.info("seats updated for booking: "+ newBooking.getBookingId());
				PaymentRequest payReq = new PaymentRequest();
				payReq.setAmount(inventory.getPricePerSeat() * request.getNumberOfPassenger());
				payReq.setBookingId(newBooking.getBookingId());
				Payment paymentResponse = paymentClient.post().uri("/addPayment").body(BodyInserters.fromValue(payReq)).header("Authorization", token).retrieve()
						.bodyToMono(Payment.class).block();
				
				
				String makePaymentResponse = paymentClient.get().uri("/makePayment/"+ paymentResponse.getPaymentId()).header("Authorization", token).retrieve()
				.bodyToMono(String.class).block();
				
				if(makePaymentResponse.equals("Done")) {
					bookingService.confirmBooking(newBooking.getBookingId());
					log.info("Payment successfull and booking confirmed");
					return new ResponseEntity<>("Payment successfull and booking confirmed", HttpStatus.OK);
				}
				
			}
		} else {
			log.info("seats are not available for bus: " + request.getBusId());
			return new ResponseEntity<>("bus not available", HttpStatus.OK);
		}
		return new ResponseEntity<>("Payment successfull and booking confirmed", HttpStatus.OK);
	}
}
