package com.sprint.booking_service.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;




@Slf4j
@Service
public class AuthService {

	@Autowired
	@Qualifier("auth-service-validate")
	private WebClient webClient;

	public boolean validateToken(String token) {

		log.info("Validating token within the AuthService: {}", token);
		log.info("Sending request to auth service to validate token: {}", token);
		Map<String, String> response = webClient.get().header("Authorization", token).retrieve()
				.onStatus(HttpStatus.UNAUTHORIZED::equals,
						res -> Mono.error(new RuntimeException("Unauthorized access - Invalid Token!")))
				.bodyToMono(Map.class).block();
		// Current Thread will pause till the final response comes back

		log.info("Response from auth service: {}", response.get("message"));

		return ((String) response.get("message")).equalsIgnoreCase("valid");
	}
}
