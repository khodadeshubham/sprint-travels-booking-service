package com.sprint.booking_service.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.booking_service.dto.BookingRequestDto;
import com.sprint.booking_service.dto.PassengerDto;
import com.sprint.booking_service.model.Booking;
import com.sprint.booking_service.model.Passenger;
import com.sprint.booking_service.repository.BookingRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BookingService {

	@Autowired
	private BookingRepository bookingRepository;
	
	public Booking addBooking(BookingRequestDto request) {
		
		Booking newBooking = new Booking();
		newBooking.setBusId(request.getBusId());
		newBooking.setNumberOfPassengers(request.getNumberOfPassenger());
		newBooking.setBookingDate(LocalDate.now());
		List<PassengerDto> passList = request.getPassengers();
		List<Passenger> passengers = new ArrayList<Passenger>();
		for(PassengerDto passenger: passList) {
			Passenger p = new Passenger();
			p.setFirstName(passenger.getFirstName());
			p.setLastName(passenger.getLastName());
			p.setBooking(newBooking);
			passengers.add(p);
		}
		
		newBooking.setPassengers(passengers);
		newBooking.setStatus("UNPAID");
		newBooking = bookingRepository.save(newBooking);
		log.info("new booking added with booking id: "+ newBooking.getBookingId());
		return newBooking;
	}
	
	public Booking confirmBooking(Long bookingId) {
		Booking newBooking = bookingRepository.findById(bookingId).get();
		newBooking.setStatus("PAID");
		return bookingRepository.save(newBooking);
	}
}
