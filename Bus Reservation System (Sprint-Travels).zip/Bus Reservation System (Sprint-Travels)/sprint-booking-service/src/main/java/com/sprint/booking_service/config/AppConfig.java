package com.sprint.booking_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AppConfig {

	@Bean(name = "auth-service-validate")
	public WebClient webClientAuthService(WebClient.Builder webClientBuilder) {
		return webClientBuilder.baseUrl("http://localhost:8081/api/auth/validate").filter(new LoggingWebClientFilter())
				.build();
	}
	
//	@Bean(name = "inventory-service-check-avaialable-seats")
//	public WebClient webClientInventoryService(WebClient.Builder webClientBuilder) {
//		return webClientBuilder.baseUrl("http://localhost:8082/api/inventory/getAvailableSeats/{busId}").filter(new LoggingWebClientFilter())
//				.build();
//	}
	
    @Bean(name = "plain-inventory-client")
    public WebClient webClientInventoryService(WebClient.Builder webClientBuilder)
    {
        return webClientBuilder
                .baseUrl("http://localhost:8082/api/inventory")
                .filter(new LoggingWebClientFilter())
                .build();
    }
    
    @Bean(name = "plain-payment-client")
    public WebClient webClientPaymentService(WebClient.Builder webClientBuilder)
    {
        return webClientBuilder
                .baseUrl("http://localhost:8084/api/payment")
                .filter(new LoggingWebClientFilter())
                .build();
    }

}
