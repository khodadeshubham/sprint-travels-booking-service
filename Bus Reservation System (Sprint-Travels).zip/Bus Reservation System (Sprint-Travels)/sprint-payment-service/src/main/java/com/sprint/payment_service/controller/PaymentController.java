package com.sprint.payment_service.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.payment_service.dto.PaymentRequest;
import com.sprint.payment_service.model.Payment;
import com.sprint.payment_service.service.AuthService;
import com.sprint.payment_service.service.PaymentService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/payment")
public class PaymentController {

	@Autowired
	private PaymentService paymentService;
	@Autowired
	private AuthService authService;
	
	@PostMapping("/addPayment")
	public ResponseEntity<?> addPayment(@RequestBody PaymentRequest request, @RequestHeader("Authorization") String token){
		if (authService.validateToken(token)) {
			Payment response = paymentService.addPayment(request);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			Map<String, String> error = new HashMap<String, String>();
			error.put("message", "Invalid token");
			return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
		}
	}
	
	@GetMapping("/makePayment/{paymentId}")
	public ResponseEntity<?> makePayment(@PathVariable("paymentId") Long paymentId, @RequestHeader("Authorization") String token){
		if (authService.validateToken(token)) {
			String response = paymentService.makePayment(paymentId);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			Map<String, String> error = new HashMap<String, String>();
			error.put("message", "Invalid token");
			return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
		}
	}
}
