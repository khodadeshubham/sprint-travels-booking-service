package com.sprint.payment_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.payment_service.dto.PaymentRequest;
import com.sprint.payment_service.model.Payment;
import com.sprint.payment_service.repository.PaymentRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PaymentService {

	@Autowired
	private PaymentRepository paymentRepository;
	
	public Payment addPayment(PaymentRequest request) {
		Payment newPayment = new Payment();
		newPayment.setBookingId(request.getBookingId());
		newPayment.setAmount(request.getAmount());
		newPayment.setStatus("UNPAID");
		paymentRepository.save(newPayment);
		log.info("Payment added for booking with status UNPAID: " + request.getBookingId());
		return newPayment;
	}
	
	public String makePayment(Long paymentId) {
		Payment payment = paymentRepository.findById(paymentId).orElse(null);
			payment.setStatus("PAID");
			paymentRepository.save(payment);
			log.info("Payment done for booking with status PAID: ");
			return "Done";
		
	}
}
