package com.sprint.inventory_service.dto;

import lombok.Data;

@Data
public class AddBusDto {
	private String start;
	private String destination;
	private int seatsAvailable;
}
