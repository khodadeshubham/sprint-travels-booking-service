package com.sprint.inventory_service.appConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AppConfig {

	@Bean(name = "auth-service-validate")
	public WebClient webClientAuthService(WebClient.Builder webClientBuilder) {
		return webClientBuilder.baseUrl("http://localhost:8081/api/auth/validate").filter(new LoggingWebClientFilter())
				.build();
	}

}
