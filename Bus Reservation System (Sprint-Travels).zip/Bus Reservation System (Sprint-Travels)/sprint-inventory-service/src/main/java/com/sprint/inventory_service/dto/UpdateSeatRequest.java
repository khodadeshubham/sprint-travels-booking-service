package com.sprint.inventory_service.dto;

import lombok.Data;

@Data
public class UpdateSeatRequest {

	private Long busId;
	private int seats;
}
