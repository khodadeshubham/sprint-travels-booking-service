package com.sprint.inventory_service.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.inventory_service.dto.AddBusDto;
import com.sprint.inventory_service.dto.UpdateSeatRequest;
import com.sprint.inventory_service.model.Inventory;
import com.sprint.inventory_service.repository.InventoryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class InventoryService {

	@Autowired
	private InventoryRepository inventoryRepository;

	public Inventory addBus(AddBusDto input) {

		Inventory newBus = new Inventory();
		newBus.setStart(input.getStart());
		newBus.setDestination(input.getDestination());
		newBus.setSeatsAvailable(input.getSeatsAvailable());
		newBus.setLastUpdate(LocalDateTime.now());

		return inventoryRepository.save(newBus);
	}

	public Optional<Inventory> getBusDetails(Long busId) {
		return inventoryRepository.findById(busId);
	}

	public String updateAvaialableSeats(UpdateSeatRequest request) {
		Inventory inventory = inventoryRepository.findById(request.getBusId()).orElse(null);
		String msg = "";
		if (inventory != null) {
			if (inventory.getSeatsAvailable() > 0 && inventory.getSeatsAvailable() > request.getSeats()) {
				inventory.setSeatsAvailable(inventory.getSeatsAvailable() - request.getSeats());
				inventoryRepository.save(inventory);
				log.info("seats updated");
				msg = "updated";
			} else {
				log.info("seats are not avaialable");
				msg = "unavailable";
			}
		}
		return msg;
	}
}
