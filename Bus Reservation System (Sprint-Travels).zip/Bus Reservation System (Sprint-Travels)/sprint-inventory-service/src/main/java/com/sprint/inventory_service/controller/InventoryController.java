package com.sprint.inventory_service.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.inventory_service.dto.AddBusDto;
import com.sprint.inventory_service.dto.UpdateSeatRequest;
import com.sprint.inventory_service.model.Inventory;
import com.sprint.inventory_service.service.AuthService;
import com.sprint.inventory_service.service.InventoryService;

import jakarta.websocket.server.PathParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

	@Autowired
	private InventoryService inventoryService;

	@Autowired
	private AuthService authService;

	@PostMapping("/addBus")
	public ResponseEntity<?> addBus(@RequestBody AddBusDto busDto, @RequestHeader("Authorization") String token) {
		if (authService.validateToken(token)) {
			Inventory response = inventoryService.addBus(busDto);
			log.info("bus added to inventory");
			return new ResponseEntity<Inventory>(response, HttpStatus.OK);
		} else {
			Map<String, String> error = new HashMap<String, String>();
			error.put("message", "Invalid token");
			return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
		}

	}
	
	@GetMapping("/getBusDetails/{busId}")
	public ResponseEntity<?> getBusDetails(@PathVariable("busId") Long busId, @RequestHeader("Authorization") String token){
		if (authService.validateToken(token)) {
			Inventory response = inventoryService.getBusDetails(busId).orElse(null);
			log.info("bus added to inventory");
			return new ResponseEntity<Inventory>(response, HttpStatus.OK);
		} else {
			Map<String, String> error = new HashMap<String, String>();
			error.put("message", "Invalid token");
			return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
		}
	}
	
	@PostMapping("/updateSeats")
	public ResponseEntity<?> updateAvailableSeats(@RequestBody UpdateSeatRequest request, @RequestHeader("Authorization") String token){
		if (authService.validateToken(token)) {
			String response = inventoryService.updateAvaialableSeats(request);
			log.info("bus added to inventory");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			Map<String, String> error = new HashMap<String, String>();
			error.put("message", "Invalid token");
			return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
		}
	}
}
